﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WDTF
{
    public class TestCaseList
    {
        public static readonly TestCaseDefinition[] TEST_CASES = 
        { 
           new WDTF_TestCase1(),
        };
    }
}
